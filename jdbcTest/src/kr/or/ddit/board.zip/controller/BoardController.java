package kr.or.ddit.board.controller;

import java.util.List;
import java.util.Scanner;

import kr.or.ddit.board.service.BoardServiceImpl;
import kr.or.ddit.board.service.IBoardService;
import kr.or.ddit.board.vo.BoardVO;

public class BoardController {
	private Scanner scan;
	private IBoardService service;
	
	public BoardController() {
		scan = new Scanner(System.in);
		service = BoardServiceImpl.getInstance();
	}
	
	public static void main(String[] args) {
		new BoardController().boardStart();

	}
	
	public void boardStart() {
		while(true){
			int input = displayMenu();
			switch(input){
			case 1:
				insertBoard();
				break;
			case 2:
				selectBoard();
				break;
			case 3:
				searchBoard();
				break;
			case 0:
				System.out.println("게시판 프로그램 종료...");
				System.exit(0);
			default:
				System.out.println("잘못 입력하였습니다");
				System.out.println("다시 입력해주세요");
			}
		}
	}
	
	public void detailStart(int boardNo) {
		int input = detailMenu();
		switch(input){
		case 1:
			updateBoard(boardNo);
			break;
		case 2:
			deleteBoard(boardNo);
			break;
		case 3:
			break;
		default:
			System.out.println("잘못입력하였습니다");
			boardStart();
			break;
		}
	}
	
	public int displayMenu() {
		listBoard();
		System.out.println("메뉴 : 1.새글작성\t2.게시물보기\t3.검색\t0.작업끝");
		System.out.print("작업선택 >> ");
		return scan.nextInt();
	}
	
	public int detailMenu() {
		System.out.println("메뉴 : 1.수정\t2.삭제\t3.리스트로 가기");
		System.out.print("작업선택 >> ");
		return scan.nextInt();
	}
	
	public void listBoard() {
		List<BoardVO> boardList = service.getAllList();
		System.out.println();
		System.out.println("===============================================");
		System.out.println(" No\t제목\t작성자\t조회수");
		System.out.println("===============================================");
		
		if(boardList.size() == 0){
			System.out.println("출력할 게시물이 없습니다");
		} else {
			for(int i = boardList.size()-1; i >= 0; i--){
				System.out.print(boardList.get(i).getBoard_no() + "\t");
				System.out.print(boardList.get(i).getBoard_title() + "\t");
				System.out.print(boardList.get(i).getBoard_writer() + "\t");
				System.out.println(boardList.get(i).getBoard_cnt() + "\t");
			}
		}
		System.out.println("===============================================");
	}
	
	public void insertBoard() {
		System.out.println();
		System.out.println("새글 작성하기");
		System.out.println("-----------------------------------");
		
		scan.nextLine();
		System.out.print("- 제 목 : ");
		String boardTitle = scan.nextLine();
		
		System.out.print("- 작성자 : ");
		String boardWriter = scan.next();
		
		scan.nextLine();
		System.out.print("- 내 용 : ");
		String boardContent = scan.nextLine();
		
		// 입력한 데이터들을 VO 객체에 저장한다
		BoardVO boardVo = new BoardVO();
		boardVo.setBoard_title(boardTitle);
		boardVo.setBoard_writer(boardWriter);
		boardVo.setBoard_content(boardContent);
		
		int cnt = service.insertBoard(boardVo);
		
		if(cnt > 0) {
			System.out.println("새 글이 추가되었습니다");
		} else {
			System.out.println("새 글이 추가되지 않았습니다");
		}
	}
	
	public void selectBoard() {
		System.out.println();
		System.out.print("보기를 원하는 게시물 번호 입력 >> ");
		int boardNo = scan.nextInt();
		
		List<BoardVO> boardList = service.selectBoard(boardNo);
		
		System.out.println();
		System.out.println(boardNo + "번 글 내용");
		System.out.println("-----------------------------------------------");
		for(BoardVO b : boardList){
			System.out.println("- 제 목 : " + b.getBoard_title());
			System.out.println("- 작성자 : " + b.getBoard_writer());
			System.out.println("- 내 용 : " + b.getBoard_content());
			System.out.println("- 작성일 : " + b.getBoard_date());
			System.out.println("- 조회수 : " + b.getBoard_cnt());
		}
		System.out.println("-----------------------------------------------");
		
		detailStart(boardNo);
	}
	
	public void searchBoard() {
		System.out.println();
		System.out.println("검색 작업");
		System.out.println("-----------------------------------");
		System.out.print("- 검색할 제목 입력 : ");
		scan.nextLine();
		String searchBoard = scan.nextLine();
		
		List<BoardVO> boardList = service.searchBoard(searchBoard);
		
		System.out.println();
		System.out.println("-----------------------------------");
		System.out.println(" No\t제목\t작성자\t조회수");
		System.out.println("-----------------------------------");
		
		if(boardList.size() == 0){
			System.out.println("검색한 게시물이 없습니다");
		} else {
			for(int i = boardList.size()-1; i >= 0; i--){
				System.out.print(boardList.get(i).getBoard_no() + "\t");
				System.out.print(boardList.get(i).getBoard_title() + "\t");
				System.out.print(boardList.get(i).getBoard_writer() + "\t");
				System.out.println(boardList.get(i).getBoard_cnt() + "\t");
			}
		}
		System.out.println("-----------------------------------");
		
	}
	
	public void updateBoard(int boardNo) {
		System.out.println();
		System.out.println("수정 작업하기");
		System.out.println("-----------------------------------");
		
		scan.nextLine();
		System.out.print("- 제 목 : ");
		String boardTitle = scan.nextLine();
		
		System.out.print("- 내 용 : ");
		String boardContent = scan.next();
		System.out.println("-----------------------------------");
		
		BoardVO boardVo = new BoardVO();
		boardVo.setBoard_title(boardTitle);
		boardVo.setBoard_content(boardContent);
		boardVo.setBoard_no(boardNo);
		
		int cnt = service.updateBoard(boardVo);
		
		if(cnt > 0) {
			System.out.println(boardNo + "번글이 수정되었습니다");
		} else {
			System.out.println(boardNo + "번글이 수정에 실패했습니다");
		}
	}
	
	public void deleteBoard(int boardNo){
		System.out.println();
		
		int cnt = service.deleteBoard(boardNo);
		
		if(cnt > 0) {
			System.out.println(boardNo + "번글이 삭제되었습니다");
		} else {
			System.out.println(boardNo + "번글이 삭제되지 않았습니다");
		}
	}
}
